@extends('template')

@section('content')

    <p class="text-small margin-bottom-20">

        <div class="alert alert-warning">You do not have permission to view this page.</div>

    </p>

@stop




