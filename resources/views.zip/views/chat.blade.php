<div class="panel-body no-padding">
	<div class="panel-scroll height-330 perfect-scrollbar ps-container ps-active-y" id="chatBox">
		<ol class="discussion">
			<li class="messages-date">
				Sunday, Mar 9, 12:58
			</li>
			<li class="self">
				<div class="message">
					<div class="message-name">
						Adams
					</div>
					<div class="message-text">
						Hi, Kendi
					</div>
					<div class="message-avatar">
						<img src="assets/images/tuva-small.jpg" alt="">
					</div>
				</div>
				<div class="message">
					<div class="message-name">
						Adams
					</div>
					<div class="message-text">
						How are you?
					</div>
					<div class="message-avatar">
						<img src="assets/images/tuva-small.jpg" alt="">
					</div>
				</div>
			</li>
			<li class="other">
				<div class="message">
					<div class="message-name">
						Kendi
					</div>
					<div class="message-text">
						Hi, i am good
					</div>
					<div class="message-avatar">
						<img src="assets/images/avatar-2.jpg" alt="">
					</div>
				</div>
			</li>
			<li class="self">
				<div class="message">
					<div class="message-name">
						Adams
					</div>
					<div class="message-text">
						I will be in office shortly
					</div>
					<div class="message-avatar">
						<img src="assets/images/tuva-small.jpg" alt="">
					</div>
				</div>
			</li>
			<li class="messages-date">
				Sunday, Mar 9, 13:10
			</li>
			<li class="other">
				<div class="message">
					<div class="message-name">
						Kendi
					</div>
					<div class="message-text">
						Okay!
					</div>
					<div class="message-avatar">
						<img src="assets/images/avatar-2.jpg" alt="">
					</div>
				</div>
			</li>
			<li class="messages-date">
				Sunday, Mar 9, 15:28
			</li>
			<li class="other">
				<div class="message">
					<div class="message-name">
						Kendi
					</div>
					<div class="message-text">
						Please come with Bamba 100
					</div>
					<div class="message-avatar">
						<img src="assets/images/avatar-2.jpg" alt="">
					</div>
				</div>
				<div class="message">
					<div class="message-name">
						Kendi
					</div>
					<div class="message-text">
						for Safaricom
					</div>
					<div class="message-avatar">
						<img src="assets/images/avatar-2.jpg" alt="">
					</div>
				</div>
			</li>
			<li class="self">
				<div class="message">
					<div class="message-name">
						Adams
					</div>
					<div class="message-text">
						I am here already
					</div>
					<div class="message-avatar">
						<img src="assets/images/tuva-small.jpg" alt="">
					</div>
				</div>
				
			</li>
			
		</ol>
	<div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 330px; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 92px;"></div></div></div>
</div>