<h3>Hi, {{ $firstname }}!</h3>
 
<p>We'd like to personally welcome you to the BWA CRM Application. Thank you for joining us!</p>
