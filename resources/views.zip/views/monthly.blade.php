<div class="panel no-radius">
	<div class="panel-heading">
		<h4 class="panel-title">
		<a href="#collapseThree" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle padding-15 collapsed">
			<i class="icon-arrow"></i>
			March, 2015
		</a></h4>
	</div>
	<div class="panel-collapse collapse" id="collapseThree">
		<div class="panel-body no-padding partition-light-grey">
			<table class="table">
				<tbody>
					<tr>
						<td class="center">1</td>
						<td>Invoices Created</td>
						<td class="center">28</td>
					</tr>
					<tr>
						<td class="center">2</td>
						<td>Expected Collections (Ksh.)</td>
						<td class="center">470,000</td>
					</tr>
					<tr >
						<td class="center">3</td>
						<td>Amount Overdue (Ksh.)</td>
						<td class="center">20,000</td>
					</tr>
					<tr>
						<td class="center">4</td>
						<td>Total Collections (Ksh.)</td>
						<td class="center">450,000</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>


<div class="panel no-radius">
	<div class="panel-heading">
		<h4 class="panel-title">
		<a href="#collapseTwo" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle padding-15 collapsed">
			<i class="icon-arrow"></i>
			February, 2015
		</a></h4>
	</div>
	<div class="panel-collapse collapse" id="collapseTwo">
		<div class="panel-body no-padding partition-light-grey">
			<table class="table">
				<tbody>
					<tr>
						<td class="center">1</td>
						<td>Invoices Created</td>
						<td class="center">28</td>
					</tr>
					<tr>
						<td class="center">2</td>
						<td>Expected Collections (Ksh.)</td>
						<td class="center">470,000</td>
					</tr>
					<tr>
						<td class="center">3</td>
						<td>Amount Overdue (Ksh.)</td>
						<td class="center">20,000</td>
					</tr>
					<tr>
						<td class="center">4</td>
						<td>Total Collections (Ksh.)</td>
						<td class="center">450,000</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>


<div class="panel no-radius">
	<div class="panel-heading">
		<h4 class="panel-title">
		<a href="#collapseOne" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle padding-15 collapsed">
			<i class="icon-arrow"></i>
			January, 2015
		</a></h4>
	</div>
	<div class="panel-collapse collapse" id="collapseOne">
		<div class="panel-body no-padding partition-light-grey">
			<table class="table">
				<tbody>
					<tr>
						<td class="center">1</td>
						<td>Invoices Created</td>
						<td class="center">28</td>
					</tr>
					<tr>
						<td class="center">2</td>
						<td>Expected Collections (Ksh.)</td>
						<td class="center">470,000</td>
					</tr>
					<tr>
						<td class="center">3</td>
						<td>Amount Overdue (Ksh.)</td>
						<td class="center">20,000</td>
					</tr>
					<tr>
						<td class="center">4</td>
						<td>Total Collections (Ksh.)</td>
						<td class="center">450,000</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="panel no-radius">
	<div class="panel-heading">
		<h4 class="panel-title">
		<a href="#collapseOne" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle padding-15 collapsed">
			<i class="icon-arrow"></i>
			December, 2014
		</a></h4>
	</div>
	<div class="panel-collapse collapse" id="collapseOne">
		<div class="panel-body no-padding partition-light-grey">
			<table class="table">
				<tbody>
					<tr>
						<td class="center">1</td>
						<td>Invoices Created</td>
						<td class="center">28</td>
					</tr>
					<tr>
						<td class="center">2</td>
						<td>Expected Collections (Ksh.)</td>
						<td class="center">470,000</td>
					</tr>
					<tr>
						<td class="center">3</td>
						<td>Amount Overdue (Ksh.)</td>
						<td class="center">20,000</td>
					</tr>
					<tr>
						<td class="center">4</td>
						<td>Total Collections (Ksh.)</td>
						<td class="center">450,000</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div

<div class="panel no-radius">
	<div class="panel-heading">
		<h4 class="panel-title">
		<a href="#collapseOne" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle padding-15 collapsed">
			<i class="icon-arrow"></i>
			November, 2014
		</a></h4>
	</div>
	<div class="panel-collapse collapse" id="collapseOne">
		<div class="panel-body no-padding partition-light-grey">
			<table class="table">
				<tbody>
					<tr>
						<td class="center">1</td>
						<td>Invoices Created</td>
						<td class="center">28</td>
					</tr>
					<tr>
						<td class="center">2</td>
						<td>Expected Collections (Ksh.)</td>
						<td class="center">470,000</td>
					</tr>
					<tr>
						<td class="center">3</td>
						<td>Amount Overdue (Ksh.)</td>
						<td class="center">20,000</td>
					</tr>
					<tr>
						<td class="center">4</td>
						<td>Total Collections (Ksh.)</td>
						<td class="center">450,000</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div