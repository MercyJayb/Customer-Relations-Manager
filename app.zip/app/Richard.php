<?php namespace CRM;

use Illuminate\Database\Eloquent\Model;


	//

}
