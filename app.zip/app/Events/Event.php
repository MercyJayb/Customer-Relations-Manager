<?php namespace CRM\Events;

abstract class Event {

	//

}
