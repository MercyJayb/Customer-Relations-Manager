<?php namespace CRM\Commands;

abstract class Command {

	//

}
